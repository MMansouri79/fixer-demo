from fixer.handler import get_rates

__all__ = ['get_rates']