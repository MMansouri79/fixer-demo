def get_rates():
    print('Package Test')